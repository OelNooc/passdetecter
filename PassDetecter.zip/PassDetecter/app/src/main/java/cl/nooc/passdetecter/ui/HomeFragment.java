package cl.nooc.passdetecter.ui;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import cl.nooc.passdetecter.R;
import cl.nooc.passdetecter.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);

        new Handler().postDelayed(() -> {
            Navigation.findNavController(getView()).navigate(R.id.action_homeFragment_to_passFragment);
        }, 5000);

        return binding.getRoot();
    }
}