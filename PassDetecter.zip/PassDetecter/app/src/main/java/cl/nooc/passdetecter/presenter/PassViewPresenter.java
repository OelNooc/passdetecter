package cl.nooc.passdetecter.presenter;

public interface PassViewPresenter {

    void mostrarNuloError(int error);
    void mostrarNivelSeguridad(int cont);
}
