package cl.nooc.passdetecter.presenter;

public interface PassPresenter {

    void longitud(String s);
    void conMayus(String s);
    void conNums(String s);
}
