package cl.nooc.passdetecter.presenter;

import cl.nooc.passdetecter.R;
import cl.nooc.passdetecter.modelo.Verifier;

public class PassPresenterImpl implements PassPresenter{

    private Verifier verifier = new Verifier();
    private PassViewPresenter view;
    private int cont = 0;

    public PassPresenterImpl(PassViewPresenter view){this.view = view;}

    public int getCont() {
        return cont;
    }

    public void setCont(int cont) {
        this.cont = cont;
    }

    @Override
    public void longitud(String s) {
        if (error(s)){
           if (verifier.longitudPass(s)){
               cont ++;
           }
        }
    }

    @Override
    public void conMayus(String s) {
        if (error(s)){
            if (verifier.tieneMayusculas(s)){
                cont ++;
            }
        }
    }

    @Override
    public void conNums(String s) {
        if (error(s)){
            if (verifier.tieneNumeros(s)){
                cont ++;
            }
        }
    }


    private boolean error(String s){
        boolean b;
        if (s.isEmpty()){
            b = false;
            view.mostrarNuloError(R.string.nulo_error);
        } else {
            b = true;
        }
        return b;
    }
}
