package cl.nooc.passdetecter.ui;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import cl.nooc.passdetecter.R;

import cl.nooc.passdetecter.databinding.FragmentPassBinding;
import cl.nooc.passdetecter.presenter.PassPresenterImpl;
import cl.nooc.passdetecter.presenter.PassViewPresenter;

public class PassFragment extends Fragment implements PassViewPresenter {

    private FragmentPassBinding binding;
    private PassPresenterImpl presenter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentPassBinding.inflate(inflater, container, false);

        presenter = new PassPresenterImpl(this);

        binding.etPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                presenter.setCont(0);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String pass = s.toString();
                presenter.longitud(pass);
                presenter.conMayus(pass);
                presenter.conNums(pass);
                mostrarNivelSeguridad(presenter.getCont());
            }
        });

        return binding.getRoot();
    }

    @Override
    public void mostrarNuloError(int error) {
        binding.etPass.setError(getString(error));
        binding.etPass.requestFocus();
    }

    @Override
    public void mostrarNivelSeguridad(int cont) {
        if(cont == 0){
            binding.tvSeguridad.setText(R.string.debil);
            binding.tvSeguridad.setBackgroundColor(Color.RED);
        } else  if(cont == 1){
            binding.tvSeguridad.setText(R.string.media);
            binding.tvSeguridad.setBackgroundColor(Color.MAGENTA);
        } else  if(cont == 2){
            binding.tvSeguridad.setText(R.string.fuerte);
            binding.tvSeguridad.setBackgroundColor(Color.YELLOW);
        } else  if(cont == 3){
            binding.tvSeguridad.setText(R.string.muy_fuerte);
            binding.tvSeguridad.setBackgroundColor(Color.GREEN);
        }
    }
}