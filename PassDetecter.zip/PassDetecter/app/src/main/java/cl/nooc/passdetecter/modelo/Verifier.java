package cl.nooc.passdetecter.modelo;

public class Verifier {

    private String pass;

    public boolean longitudPass(String pass) {
        boolean aux;
        if (pass.length() <= 5) {
            aux = false;
        } else {
            aux = true;
        }
        return aux;
    }

    public boolean tieneMayusculas(String pass) {
        for (int i = 0; i < pass.length(); i++) {
            if (Character.isUpperCase(pass.charAt(i))) {
                return true;
            }
        }
        return false;

    }

    public boolean tieneNumeros(String pass) {
        for (int i = 0; i < pass.length(); i++) {
            if (Character.isDigit(pass.charAt(i))) {
                return true;
            }
        }
        return false;
    }
}
